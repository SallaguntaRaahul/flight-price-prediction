from flask import Flask, request, render_template
import pandas as pd
import pickle

app = Flask(__name__)
model = pickle.load(open("m.pkl", "rb"))  # Ensure the model path is correct

@app.route("/")

def home():
    return render_template("home.html")

@app.route("/predict", methods=["GET", "POST"])

def predict():
    if request.method == "POST":
        # Extracting and converting the date and time inputs
        date_dep = request.form["Dep_Time"]
        Journey_day = int(pd.to_datetime(date_dep, format="%Y-%m-%dT%H:%M").day)
        Journey_month = int(pd.to_datetime(date_dep, format="%Y-%m-%dT%H:%M").month)
        Dep_hour = int(pd.to_datetime(date_dep, format="%Y-%m-%dT%H:%M").hour)
        Dep_min = int(pd.to_datetime(date_dep, format="%Y-%m-%dT%H:%M").minute)
        
        date_arr = request.form["Arrival_Time"]
        Arrival_hour = int(pd.to_datetime(date_arr, format="%Y-%m-%dT%H:%M").hour)
        Arrival_min = int(pd.to_datetime(date_arr, format="%Y-%m-%dT%H:%M").minute)
        
        # Calculating duration in minutes
        Duration_minutes = abs((Arrival_hour * 60 + Arrival_min) - (Dep_hour * 60 + Dep_min))
        
        # Total stops
        Total_stops = int(request.form["Total_Stops"])
        
        # Airline one-hot encoding
        airline = request.form['Airline']
        airline_features = {f'Airline_{airline.upper()}': 1}
        
        # Source one-hot encoding
        source = request.form['Source']
        source_features = {f'Source_{source.upper()}': 1}
        
        # Destination one-hot encoding
        destination = request.form['Destination']
        destination_features = {f'Destination_{destination.upper()}': 1}
        
        # Combine all features into a single dictionary
        features = {
            'Total_Stops': Total_stops,
            'Journey_Day': Journey_day,
            'Journey_Month': Journey_month,
            'Depature_Hours': Dep_hour,
            'Depature_Minutes': Dep_min,
            'Arrival_Hours': Arrival_hour,
            'Arrival_Minutes': Arrival_min,
            'Duration_Minutes': Duration_minutes,
        }
        features.update(airline_features)
        features.update(source_features)
        features.update(destination_features)
        
        # Feature ordering as expected by the model
        feature_order = [
            'Total_Stops', 'Price', 'Depature_Hours', 'Depature_Minutes', 'Arrival_Hours',
            'Arrival_Minutes', 'Journey_Day', 'Journey_Month', 'Duration_Minutes',
            'Airline_AIR ASIA', 'Source_CHENNAI', 'Source_DELHI', 'Source_KOLKATA', 'Source_MUMBAI',
            'Destination_BANGLORE', 'Destination_COCHIN', 'Destination_DELHI', 'Destination_HYDERABAD',
            'Destination_KOLKATA', 'Destination_NEW DELHI'
        ]
        model_input = [features.get(f, 0) for f in feature_order]  # Default to 0 if the feature key is not found
        
        # Predict using the model
        prediction = model.predict([model_input])
        output = round(prediction[0], 2)

        return render_template('index.html', prediction_text="Your Flight price is Rs. {}".format(output))

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
